package com.example.backend.controller;

import com.example.backend.dto.MovieRequest;
import com.example.backend.model.Movie;
import com.example.backend.repository.MovieRepository;
import com.example.backend.service.MovieService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RequestMapping("/api/movies")
@RestController
public class MovieController {

    private final Logger logger = LoggerFactory.getLogger(MovieController.class);

    @Autowired
    private MovieService movieService;  // Inject MovieService

    @Autowired
    private MovieRepository movieRepository;

    @PostMapping(value = "/add", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> addMovie(
            @RequestParam("name") String name,
            @RequestParam("duration") String duration,
            @RequestParam("image") MultipartFile image,
            @RequestParam("description") String description) {
        try {
            if (image.isEmpty()) {
                return ResponseEntity.badRequest().body("Hình ảnh không được để trống!");
            }

            // Lưu ảnh và tạo movie
            String imageUrl = movieService.saveImage(image);

            Movie movie = new Movie();
            movie.setName(name);
            movie.setDuration(duration);
            movie.setImageUrl(imageUrl);
            movie.setDescription(description);

            Movie newMovie = movieService.addMovie(movie);
            return ResponseEntity.ok(newMovie);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Lỗi hệ thống: " + e.getMessage());
        }
    }

    //API lấy danh sách phim
    @GetMapping("/get")
    public ResponseEntity<?> getMovies() {
        try {
            List<Movie> movies = movieService.getAllMovies();
            logger.info("Movies List: {}", movies);
            return ResponseEntity.ok(movies);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error" + e.getMessage());
        }
    }

    //Tạo API tìm phim
    @GetMapping("/search")
    public ResponseEntity<?> searchMovie(@RequestParam String name){
        List<Movie> movies = movieService.searchMovies(name);
        if (movies.isEmpty()){
            return ResponseEntity.notFound().build(); // Trả về 404 nếu không tìm thấy phim
        }
        return ResponseEntity.ok(movies); // Trả về danh sách phim
    }
    // API xóa tất cả phim
    @DeleteMapping("/delete")
    public String deleteAllMovies(String confirm) {
        // tạo confirm xác nhận xóa
        if(!"CONFIRM".equals(confirm)){
            return "Vui lòng xác nhận bằng cách gửi 'CONFIRM!'";
        }
        movieRepository.deleteAll();
        return "Toàn bộ dữ liệu đã bị xóa";
    }

    //API xóa movie theo id
    @DeleteMapping("/delete/{movieId}")
    public String deleteMovieById(@PathVariable long movieId){
        movieRepository.deleteById(movieId);
        return "Phim đã xóa !";
    }
}

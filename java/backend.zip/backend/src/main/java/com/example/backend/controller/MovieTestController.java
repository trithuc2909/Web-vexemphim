package com.example.backend.controller;

import com.example.backend.model.Movie;
import com.example.backend.model.MovieTest;
import com.example.backend.service.MovieTestService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/movietest")
@CrossOrigin("*")
public class MovieTestController {
    private MovieTestService movieTestService;

    public MovieTestController(MovieTestService movieTestService){
        this.movieTestService = movieTestService;
    }

    @PostMapping(value = "/add", consumes = "multipart/form-data")
    public ResponseEntity<?> addMovie(
            @RequestParam("name") String name,
            @RequestParam("duration") String duration,
            @RequestParam("image") MultipartFile image,
            @RequestParam("description") String description) {

        try {
            // Lưu ảnh
            String image1 = movieTestService.saveImage(image);
            if (image1 == null) {
                return ResponseEntity.badRequest().body("Không thể lưu ảnh!");
            }

            // Tạo đối tượng Movie
            MovieTest movieTest = new MovieTest();
            movieTest.setName(name);
            movieTest.setDuration(duration);
            movieTest.setDescription(description);
            movieTest.setImage(image1);

            // Lưu vào database
            MovieTest newMovieTest = movieTestService.addMovie(movieTest);
            return ResponseEntity.ok(newMovieTest);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().body("Lỗi hệ thống: " + e.getMessage());
        }
    }

}

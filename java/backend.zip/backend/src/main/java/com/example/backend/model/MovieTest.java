package com.example.backend.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@Entity
public class MovieTest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long movieId;

    @Column(name = "name",nullable = false, length = 255) // Không cho phép null và giới hạn độ dài
    private String name;

    @Column( name = "image",length = 500) //ảnh có thể null
    private String image;

    @Column( name = "description",length = 1000)
    private String description;

    @Column( name = "duration",columnDefinition = "TEXT")
    private String duration;

    @Column(name = "page_url", nullable = true)
    private String pageUrl;

    public MovieTest (String name, String imageUrl, String description, String duration, String pageUrl ){
        this.name = name;
        this.image = image;
        this.description = description;
        this.duration = duration;
        this.pageUrl = pageUrl;
    }
}

package com.example.backend.service;

import com.example.backend.dto.MovieRequest;
import com.example.backend.model.Movie;
import com.example.backend.repository.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class MovieService {
    private final MovieRepository movieRepository;

    @Autowired
    public MovieService(MovieRepository movieRepository){
        this.movieRepository = movieRepository;
    }

    private static final String UPLOAD_DIR = "src/main/resources/static/uploads/";
    // Thêm mới phim
    public String saveImage(MultipartFile file) {
        if (file.isEmpty()) {
            return null;
        }
        try {
            // Tạo tên file duy nhất
            String fileName = UUID.randomUUID() + "_" + file.getOriginalFilename();
            Path path = Paths.get(UPLOAD_DIR + fileName);

            // Kiểm tra thư mục lưu trữ
            File uploadDir = new File(UPLOAD_DIR);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();  // Dùng mkdirs() để tạo thư mục nếu chưa tồn tại
            }

            // Lưu file
            file.transferTo(path.toFile());

            return "/uploads/" + fileName; // Trả về URL ảnh
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    public Movie addMovie(Movie movie) {
        return movieRepository.save(movie);
    }

    //Lưu phim vào Database
    public Movie createMovie(Movie movie){
        return movieRepository.save(movie);
    }

    //Lấy danh sách tất cả các phim
    public List<Movie> getAllMovies(){
        return movieRepository.findAll(); // Lấy tất cả các phim từ cơ sở dữ liệu
    }

    //Tìm phim theo ID
    public Movie getMovieById(Long movieId){
        return movieRepository.findById(movieId).orElseThrow(() -> new RuntimeException("Movie not found"));
    }

    //Xóa phim theo ID
    public void deleteMovieById(Long movieId){
        movieRepository.deleteById(movieId);
    }

    public List<Movie> searchMovies (String name) {
        List<Movie> movies = movieRepository.findByNameContainingIgnoreCase(name);
        return movies.isEmpty() ? new ArrayList<>() : movies;
    }

}

package com.example.backend.service;

import com.example.backend.model.MovieTest;
import com.example.backend.repository.MovieTestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@Service
public class MovieTestService {
    @Autowired
    private MovieTestRepository movieTestRepository;


    private static final String UPLOAD_DIR = "uploads/";



    public MovieTestService(MovieTestRepository movieTestRepository) {
        this.movieTestRepository = movieTestRepository;
    }

    // Lưu ảnh vào thư mục và trả về đường dẫn
    public String saveImage(MultipartFile file) {
        if (file.isEmpty()) {
            System.out.println("File ảnh rỗng!");
            return null;
        }
        try {
            // Tạo tên file duy nhất
            String fileName = UUID.randomUUID() + "_" + file.getOriginalFilename();
            Path path = Paths.get(UPLOAD_DIR + fileName);

            // Kiểm tra thư mục
            File uploadDir = new File(UPLOAD_DIR);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }

            // Lưu file
            file.transferTo(path.toFile());

            return "/uploads/" + fileName; // Trả về đường dẫn để lưu vào CSDL
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Thêm mới phim
    public MovieTest addMovie(MovieTest movieTest) {
        return movieTestRepository.save(movieTest);
    }
}
